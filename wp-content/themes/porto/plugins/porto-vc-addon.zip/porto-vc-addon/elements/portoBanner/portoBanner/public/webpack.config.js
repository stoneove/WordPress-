module.exports = {
    entry: {
        'portoBanner': ['./js/portoBanner.js']
    },
    output: {
        filename: '[name].min.js'
    }
}